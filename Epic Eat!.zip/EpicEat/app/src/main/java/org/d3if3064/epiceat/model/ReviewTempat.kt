package org.d3if3064.epiceat.model

data class ReviewTempat(
    val nama: String,
    val namaLatin: String,
    val imageId: String
)
