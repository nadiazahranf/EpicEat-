package org.d3if3064.epiceat.model

data class MessageResponse(
    val message: String,
    val status: Boolean
)
