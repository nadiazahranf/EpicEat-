package org.d3if3064.epiceat.model

data class User(
    val name: String = "",
    val email: String = "",
    val photoUrl: String = ""
)

